Support
-------
If you are having issues, please let us know.
We have a mailing list located at: daniel@innova-t.info
License
-------
The project is licensed under the LGPL-3 license.
